using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    [SerializeField] private GameObject _MusicBoxContainer;
    [SerializeField] private AudioSource[] _audioSource;

    private void Awake()
    {
        _audioSource = FindObjectsOfType<AudioSource>();
    }

    private void Start()
    {
        foreach (AudioSource audioSource in _audioSource)
            audioSource.Play();
    }
}
