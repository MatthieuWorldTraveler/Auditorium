using UnityEngine;

public class RaycastMouse : MonoBehaviour
{
    [SerializeField] private LayerMask _layer;
    [SerializeField] private Texture2D _cursorMove, _cursorResize, _cursorNormal;
    Camera _camera;

    private void Start()
    {
        _camera = GetComponent<Camera>();
    }

    private void Update()
    {
        Ray ray = _camera.ScreenPointToRay(Input.mousePosition);
        Debug.DrawRay(ray.origin, ray.direction * 20, Color.red);

        RaycastHit2D hit = Physics2D.GetRayIntersection(ray, 20f, _layer);

        //if(hit.collider != null && Input.GetButtonDown("Fire1"))

        //Debug.Log(hit.collider.GetComponent<Transform>());
        if (hit.collider != null)
        {
            Transform effector = hit.collider.GetComponent<Transform>();
            if (effector.CompareTag("MoveEffector"))
            {
                Cursor.SetCursor(_cursorMove, Vector2.zero, CursorMode.Auto);
            }
            else if (effector.CompareTag("ResizeEffector"))
            {
                Cursor.SetCursor(_cursorResize, Vector2.zero, CursorMode.Auto);
            }
            else
                Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);

        }
    }


}
