using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VolumeSync : MonoBehaviour
{
    [SerializeField] private Material _allume, _eteint;

    [SerializeField] private Renderer[] _volumeBarre;
    AudioSource _audioSource;

    private void Awake()
    {
        _audioSource = GetComponent<AudioSource>();
        _volumeBarre = GetComponentsInChildren<Renderer>();
    }

    private void Start()
    {
        VolumeCheck();
    }

    public void VolumeCheck()
    {
        for (int i = 1; i < _volumeBarre.Length; i++)
        {
            if (_audioSource.volume >= Mathf.Abs(i * 0.2f))
            {
                _volumeBarre[i].material = _allume;
                //Debug.Log(_volumeBarre[i].material + "True : " + i + " // Audio volume : " + _audioSource.volume + "/ Valeur param�tre if : " + i * 0.2f);
            }
            else
            {
                _volumeBarre[i].material = _eteint; 
                //Debug.Log(_volumeBarre[i].material + "False : " + i + " // Audio volume : " + _audioSource.volume + "/ Valeur param�tre if : " + i * 0.2f);
            }
        }
    }
}
